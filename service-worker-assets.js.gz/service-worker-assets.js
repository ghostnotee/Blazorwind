self.assetsManifest = {
  "version": "nOJYmesD",
  "assets": [
    {
      "hash": "sha256-mOTC5Sywmh/wqNcaC2zRdfOOkRdUxJFcFec+1oS55VE=",
      "url": "Images/batman.jpg"
    },
    {
      "hash": "sha256-1N5+Rvnl8ifIjlnNVgLW6CdQ29bu60qZN0Ow4oDJNTI=",
      "url": "Images/matrix.png"
    },
    {
      "hash": "sha256-SgyhWMFtDOxa+MjAjKvSSYbjYHB1MTyJkKrsn69H3Jg=",
      "url": "Images/mv1.jpg"
    },
    {
      "hash": "sha256-Lly3/bHEe0UwYTB4Kx9jEmXnXtr5QP62MT/I7thTC4s=",
      "url": "Images/mv2.jpg"
    },
    {
      "hash": "sha256-xTAxZfc8+kcTzUxn4lbWkRcmRIexerzhaShpx3R8XJw=",
      "url": "Images/mv3.jpg"
    },
    {
      "hash": "sha256-mijo2VSWLjTpImXf64nL/N+Z5yr1/n5ooEQWYIJ9esQ=",
      "url": "Images/mv4.jpg"
    },
    {
      "hash": "sha256-rcK4k+j05n58Z/4ROjSsGEWQCNpMJFtTeSvjYwNIqWw=",
      "url": "Images/mv5.jpg"
    },
    {
      "hash": "sha256-dRHxzTfH9p0uArwyPLQavRvGS/J9o8cEJMQ84dg+5+w=",
      "url": "Images/mv6.jpg"
    },
    {
      "hash": "sha256-y6bfz3A4bBHft0DchoF+Rp+2XzAqWNB11apL1KayQs4=",
      "url": "Images/new1.jpg"
    },
    {
      "hash": "sha256-RxmGLhyvcgKqRWzWnd9XdgzlIN5NLOZVVcNzNWUQM5U=",
      "url": "Images/new2.jpg"
    },
    {
      "hash": "sha256-uQjuxH7aY8gTFFEd7w1oxrLEHsCrqGCI8iSTsTAPt9w=",
      "url": "Images/new3.jpg"
    },
    {
      "hash": "sha256-M7Q4JdJgZnv/W5Bsy7n6K8TJrkli6GbFnl3tnXS++p4=",
      "url": "Images/new4.jpg"
    },
    {
      "hash": "sha256-eNb8ClsjrZD251hKJmrCflVjJAigQ9Nfk456mTiwyEc=",
      "url": "Images/new5.jpg"
    },
    {
      "hash": "sha256-ntzelMUu81cLq0oQd69Dnob08mebrSs4W+oKhJMXoGg=",
      "url": "Images/userava1.jpg"
    },
    {
      "hash": "sha256-hAggfDu5CJoNADMLBTGP5iO+1nd0kLKifcYH7Q900i8=",
      "url": "Images/userava2.jpg"
    },
    {
      "hash": "sha256-SB8824h54D2su4usTIgXfgL/2ql820cae61YruyqrdY=",
      "url": "Images/userava3.jpg"
    },
    {
      "hash": "sha256-qYtxqnNIjQuKghHFjM50J+PpSguAlooYJ2+tE9s28yI=",
      "url": "Images/userava4.jpg"
    },
    {
      "hash": "sha256-6lyGrA9GorBHgpPjOlDV2MEgVSOgRSZtKvdL0oTITjo=",
      "url": "Images/userava5.jpg"
    },
    {
      "hash": "sha256-QaU3MCJZXUPpTg3z+sdNujuTSOqUW4O70/Rc6aQj1xU=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.7yvofxhswa.wasm"
    },
    {
      "hash": "sha256-D/ZUWrvE7bqOtBfOWuLj+4RNqOvNZ0SnjD6QrBwUcb8=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.pq7fdyw1tb.wasm"
    },
    {
      "hash": "sha256-8TMb11luo+nINm37LhuqhUl41Qt4qyXW5GBKod9le3A=",
      "url": "_framework/Microsoft.AspNetCore.Components.vk63sz4xa5.wasm"
    },
    {
      "hash": "sha256-AyL87FvJMf14Dcn8HeQ3n2veg/RQGVGCjfpJPt1RQC4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.f9jq6u05xu.wasm"
    },
    {
      "hash": "sha256-TUkUL2Leb3zmGe8ZZUHAzyb8vZoEzua1H8f8stc7xRw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.77nptesqpn.wasm"
    },
    {
      "hash": "sha256-0iZA+rfvr3lLmK5V18g0LZCU41c3mbTL9jNYRoavdB0=",
      "url": "_framework/Microsoft.Extensions.Configuration.ell6o7ap7i.wasm"
    },
    {
      "hash": "sha256-Ba5NdPQTvHVjnFX7kh/XyQIVNwfdoGXkKHF8w2H6PU0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.p7b5uiooiy.wasm"
    },
    {
      "hash": "sha256-EPey4pvx6aL8aj8zL05ip1ZJSUG7DjjOrtL9aPRDYPw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.g8opmrm9gr.wasm"
    },
    {
      "hash": "sha256-a881iT/kmq3LnryJklnQzsMD93/W6dM0x/3xSE38e6I=",
      "url": "_framework/Microsoft.Extensions.Logging.5g1hnmwyc5.wasm"
    },
    {
      "hash": "sha256-orBsRyrmQ2tga4R/Z9nE0NDH6jGWYutysMdSEM1i6/o=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.udb0ns9y9g.wasm"
    },
    {
      "hash": "sha256-tXQZqZqNvPMoYp2INR4AOHcvE8kWly2WAYbjvmmuiXU=",
      "url": "_framework/Microsoft.Extensions.Options.9zsgy7ya5a.wasm"
    },
    {
      "hash": "sha256-TYdWPCwhKBdHQ79Fa7lunjzdUXfcxyaR1fAk0y11/ig=",
      "url": "_framework/Microsoft.Extensions.Primitives.tcgeh3akx1.wasm"
    },
    {
      "hash": "sha256-lNqP2ot1f2PhPr/5ZgFueuYFhUgz/pVAaqmi0u4H8Lo=",
      "url": "_framework/Microsoft.JSInterop.426305nhc4.wasm"
    },
    {
      "hash": "sha256-99wG3VH14sWkwPaF5rX6YAcJvtAhDuqonwihvj2m5HA=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.heoad7mujs.wasm"
    },
    {
      "hash": "sha256-b1Ophc8vVJZRRKeRKxDhCW8I1EpmHOLHxsDT+c02eeQ=",
      "url": "_framework/System.Collections.Concurrent.rle60xevtb.wasm"
    },
    {
      "hash": "sha256-1u2cgUb+Fl3hM5P/GEAEWbzEpFYnw1RHoLwOm443+LQ=",
      "url": "_framework/System.Collections.Immutable.qk093dn8xe.wasm"
    },
    {
      "hash": "sha256-zi1pKwbu/g7H/q12ShzcZYcL8RR6HFnTTAR/IqWA20Q=",
      "url": "_framework/System.Collections.ysiwzmh6zn.wasm"
    },
    {
      "hash": "sha256-RVQ26XHFvUHy3lBi6noqu2uagIcLEZhnUHBabSFkaXo=",
      "url": "_framework/System.ComponentModel.fb6b35yifs.wasm"
    },
    {
      "hash": "sha256-6hOoO4TVa0nvzPnr+e/F+rga/Tv3ArNNeR67t+y/TVY=",
      "url": "_framework/System.Console.qn0fr8ykjl.wasm"
    },
    {
      "hash": "sha256-agBw3O5EmksaHQ40qbBY3q5NCnjZ5BLESPOj69GnF8g=",
      "url": "_framework/System.IO.Pipelines.6l78wm3be5.wasm"
    },
    {
      "hash": "sha256-wZgeR+DwVBpU2/e3RTBA7bhACjvJ8Ic1wHO75Nyqevo=",
      "url": "_framework/System.Linq.x80e080u0p.wasm"
    },
    {
      "hash": "sha256-Zh3J+KF9dQRrmZZ9euY2bDyEZ0vFNJZkbpaP5LxqM2M=",
      "url": "_framework/System.Memory.q3iv43ovpk.wasm"
    },
    {
      "hash": "sha256-V8qoLQbB/khh8BMNv84Qn5YP+urYRXmJgU5s0BwPQNM=",
      "url": "_framework/System.Net.Http.ngkjwz1def.wasm"
    },
    {
      "hash": "sha256-TQ57yanIpfdSS83FnKBn3HxPUSthPwJTM7jGjuKbHjo=",
      "url": "_framework/System.Net.Primitives.linpzmvv9q.wasm"
    },
    {
      "hash": "sha256-V77BSMYUsDAmJdhozuWimQVDVZPAdKCLRXgBhKjTvHA=",
      "url": "_framework/System.Private.CoreLib.b758m7a8hd.wasm"
    },
    {
      "hash": "sha256-lZWKvv+h1Dz3L2hkQCy/HvMfzSf50RB5FPz8W9j7v1A=",
      "url": "_framework/System.Private.Uri.rw1ji20tgm.wasm"
    },
    {
      "hash": "sha256-0TP+6/akHFjrHZGDv0NE7pmpxdrqqqaTLUUOURYuq9Y=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.fge8107jim.wasm"
    },
    {
      "hash": "sha256-zOObMUrqberzZx7z2qz/ENNzhnhxJUF1YzkHxhjcbQM=",
      "url": "_framework/System.Runtime.w1728l1wvs.wasm"
    },
    {
      "hash": "sha256-5hiRHg3FXimgfp/PNEFaSXCmGJS26W4LckFCrYKk2k0=",
      "url": "_framework/System.Text.Encodings.Web.61fgrvui92.wasm"
    },
    {
      "hash": "sha256-CkXuD/CphPdj8Suw2ax43rgsg5QJNmOo81Wei7j5454=",
      "url": "_framework/System.Text.Json.asdxhsmuys.wasm"
    },
    {
      "hash": "sha256-pBU5xrbAIhYCjypX6ly7dIHa2b5jgeiZb7xbQ+atqFA=",
      "url": "_framework/System.Text.RegularExpressions.kko5ac1sj1.wasm"
    },
    {
      "hash": "sha256-cYoRat9twbDtUJLRB/ZOlC85sW4dscsmsnP4qL5mNyk=",
      "url": "_framework/WebApp.3r0bd8h12t.wasm"
    },
    {
      "hash": "sha256-sqZrs2kefPK3l64/w6oa7dO59kp08jLOMIk5nDhBj14=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-lh8bY3DINgTiqGL/cwOeVaJGdfE2ex1o8MzwCbmlZZE=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-6AErMlc7gMr2zQXq4dlYNko4OpIPM/DbMaBgNIXJoSM=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-KipEmnHVPv346PS6vLFDZJg+YeG/D3UYlHI9udpKOiQ=",
      "url": "_framework/dotnet.native.6sals8nuk0.js"
    },
    {
      "hash": "sha256-kWgios95+ALdV18qJt0zxX9zENxbF8ifBfdPhb9Vkqw=",
      "url": "_framework/dotnet.native.zzmgzj9wb3.wasm"
    },
    {
      "hash": "sha256-dLGiRHXW5dihGFbVNpFTz1UieVuaSP9FlFdtk0cxQFo=",
      "url": "_framework/dotnet.runtime.8ha609180a.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-CLH0GpJ4RVjJc4PEP1BKkD9u+CO6Qwngg86uovO/VrY=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-R7QqkKcIMkxizlTyFLJqHBV9TjPDu3CqGHNMOBrZabg=",
      "url": "css/app.scss"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-5Q133T2P8pYaBntdckBASY7TsVVmT5pXG8Gj62W53+A=",
      "url": "index.html"
    },
    {
      "hash": "sha256-s4nQ0gm4La8wA8++Y4nW7LUZ/mm/SebLqwnbf96ZQ6w=",
      "url": "manifest.webmanifest"
    }
  ]
};
