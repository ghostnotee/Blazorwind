self.assetsManifest = {
  "version": "6rJFoF4z",
  "assets": [
    {
      "hash": "sha256-mOTC5Sywmh/wqNcaC2zRdfOOkRdUxJFcFec+1oS55VE=",
      "url": "Images/batman.jpg"
    },
    {
      "hash": "sha256-1N5+Rvnl8ifIjlnNVgLW6CdQ29bu60qZN0Ow4oDJNTI=",
      "url": "Images/matrix.png"
    },
    {
      "hash": "sha256-SgyhWMFtDOxa+MjAjKvSSYbjYHB1MTyJkKrsn69H3Jg=",
      "url": "Images/mv1.jpg"
    },
    {
      "hash": "sha256-Lly3/bHEe0UwYTB4Kx9jEmXnXtr5QP62MT/I7thTC4s=",
      "url": "Images/mv2.jpg"
    },
    {
      "hash": "sha256-xTAxZfc8+kcTzUxn4lbWkRcmRIexerzhaShpx3R8XJw=",
      "url": "Images/mv3.jpg"
    },
    {
      "hash": "sha256-mijo2VSWLjTpImXf64nL/N+Z5yr1/n5ooEQWYIJ9esQ=",
      "url": "Images/mv4.jpg"
    },
    {
      "hash": "sha256-rcK4k+j05n58Z/4ROjSsGEWQCNpMJFtTeSvjYwNIqWw=",
      "url": "Images/mv5.jpg"
    },
    {
      "hash": "sha256-dRHxzTfH9p0uArwyPLQavRvGS/J9o8cEJMQ84dg+5+w=",
      "url": "Images/mv6.jpg"
    },
    {
      "hash": "sha256-y6bfz3A4bBHft0DchoF+Rp+2XzAqWNB11apL1KayQs4=",
      "url": "Images/new1.jpg"
    },
    {
      "hash": "sha256-RxmGLhyvcgKqRWzWnd9XdgzlIN5NLOZVVcNzNWUQM5U=",
      "url": "Images/new2.jpg"
    },
    {
      "hash": "sha256-uQjuxH7aY8gTFFEd7w1oxrLEHsCrqGCI8iSTsTAPt9w=",
      "url": "Images/new3.jpg"
    },
    {
      "hash": "sha256-M7Q4JdJgZnv/W5Bsy7n6K8TJrkli6GbFnl3tnXS++p4=",
      "url": "Images/new4.jpg"
    },
    {
      "hash": "sha256-eNb8ClsjrZD251hKJmrCflVjJAigQ9Nfk456mTiwyEc=",
      "url": "Images/new5.jpg"
    },
    {
      "hash": "sha256-ntzelMUu81cLq0oQd69Dnob08mebrSs4W+oKhJMXoGg=",
      "url": "Images/userava1.jpg"
    },
    {
      "hash": "sha256-hAggfDu5CJoNADMLBTGP5iO+1nd0kLKifcYH7Q900i8=",
      "url": "Images/userava2.jpg"
    },
    {
      "hash": "sha256-SB8824h54D2su4usTIgXfgL/2ql820cae61YruyqrdY=",
      "url": "Images/userava3.jpg"
    },
    {
      "hash": "sha256-qYtxqnNIjQuKghHFjM50J+PpSguAlooYJ2+tE9s28yI=",
      "url": "Images/userava4.jpg"
    },
    {
      "hash": "sha256-6lyGrA9GorBHgpPjOlDV2MEgVSOgRSZtKvdL0oTITjo=",
      "url": "Images/userava5.jpg"
    },
    {
      "hash": "sha256-QaU3MCJZXUPpTg3z+sdNujuTSOqUW4O70/Rc6aQj1xU=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.7yvofxhswa.wasm"
    },
    {
      "hash": "sha256-D/ZUWrvE7bqOtBfOWuLj+4RNqOvNZ0SnjD6QrBwUcb8=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.pq7fdyw1tb.wasm"
    },
    {
      "hash": "sha256-8TMb11luo+nINm37LhuqhUl41Qt4qyXW5GBKod9le3A=",
      "url": "_framework/Microsoft.AspNetCore.Components.vk63sz4xa5.wasm"
    },
    {
      "hash": "sha256-AyL87FvJMf14Dcn8HeQ3n2veg/RQGVGCjfpJPt1RQC4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.f9jq6u05xu.wasm"
    },
    {
      "hash": "sha256-TUkUL2Leb3zmGe8ZZUHAzyb8vZoEzua1H8f8stc7xRw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.77nptesqpn.wasm"
    },
    {
      "hash": "sha256-0iZA+rfvr3lLmK5V18g0LZCU41c3mbTL9jNYRoavdB0=",
      "url": "_framework/Microsoft.Extensions.Configuration.ell6o7ap7i.wasm"
    },
    {
      "hash": "sha256-Ba5NdPQTvHVjnFX7kh/XyQIVNwfdoGXkKHF8w2H6PU0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.p7b5uiooiy.wasm"
    },
    {
      "hash": "sha256-EPey4pvx6aL8aj8zL05ip1ZJSUG7DjjOrtL9aPRDYPw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.g8opmrm9gr.wasm"
    },
    {
      "hash": "sha256-a881iT/kmq3LnryJklnQzsMD93/W6dM0x/3xSE38e6I=",
      "url": "_framework/Microsoft.Extensions.Logging.5g1hnmwyc5.wasm"
    },
    {
      "hash": "sha256-orBsRyrmQ2tga4R/Z9nE0NDH6jGWYutysMdSEM1i6/o=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.udb0ns9y9g.wasm"
    },
    {
      "hash": "sha256-tXQZqZqNvPMoYp2INR4AOHcvE8kWly2WAYbjvmmuiXU=",
      "url": "_framework/Microsoft.Extensions.Options.9zsgy7ya5a.wasm"
    },
    {
      "hash": "sha256-TYdWPCwhKBdHQ79Fa7lunjzdUXfcxyaR1fAk0y11/ig=",
      "url": "_framework/Microsoft.Extensions.Primitives.tcgeh3akx1.wasm"
    },
    {
      "hash": "sha256-lNqP2ot1f2PhPr/5ZgFueuYFhUgz/pVAaqmi0u4H8Lo=",
      "url": "_framework/Microsoft.JSInterop.426305nhc4.wasm"
    },
    {
      "hash": "sha256-99wG3VH14sWkwPaF5rX6YAcJvtAhDuqonwihvj2m5HA=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.heoad7mujs.wasm"
    },
    {
      "hash": "sha256-L7r3rphzURX/eAVh8FyqlaahNXllPc0Ntl59l4VVFl8=",
      "url": "_framework/System.Collections.Concurrent.10t4a4w8m8.wasm"
    },
    {
      "hash": "sha256-eCsZmQL2yHjWvMj2LWWCxgWZxCk4MhyJ46JVTxxWt5A=",
      "url": "_framework/System.Collections.Immutable.020xe2o7av.wasm"
    },
    {
      "hash": "sha256-oP2ndB2iiJUOhhIV3c/6Mq4AsamG2hnOoEkX9B91eP0=",
      "url": "_framework/System.Collections.sd3mnjufrj.wasm"
    },
    {
      "hash": "sha256-tXQpmMVs+QJaYRESF8C5FLZYQNMLjOvszNCASM8imFM=",
      "url": "_framework/System.ComponentModel.5keg7c7hvo.wasm"
    },
    {
      "hash": "sha256-e0Ak76EvlTCe+iVjIpzById4iMRPg/JSxUjdejTCR1o=",
      "url": "_framework/System.Console.5ggx2vx7yo.wasm"
    },
    {
      "hash": "sha256-q7mGEcpph+nlGWd4rmBSfmXRrRasjniRTy3iBAsX3So=",
      "url": "_framework/System.IO.Pipelines.xlksj35j40.wasm"
    },
    {
      "hash": "sha256-HpmGPYQyOiheYxTsqV8bs594GsM56nEQ1ZVkuPasw6M=",
      "url": "_framework/System.Linq.2r5kfcisag.wasm"
    },
    {
      "hash": "sha256-EOnjLGO2e1PGDr8scBOp4D5+HkYaQW0weFxpV/ATO80=",
      "url": "_framework/System.Memory.knqwklcom9.wasm"
    },
    {
      "hash": "sha256-KNXWcO0nQtXdQcQi4z38zhB7R1AhWKSeqyOo1X069po=",
      "url": "_framework/System.Net.Http.wibuhl3lgm.wasm"
    },
    {
      "hash": "sha256-1y4I/y49VU9owasFk/RaSCfU/xzaE1eELg99KlQXorg=",
      "url": "_framework/System.Net.Primitives.bn126x5ac2.wasm"
    },
    {
      "hash": "sha256-SU0OZnF1eVYezprwA4I5jPY52hLunuG2CZm2tyHmf/4=",
      "url": "_framework/System.Private.CoreLib.pg7e0wrw5z.wasm"
    },
    {
      "hash": "sha256-M4EZBEXvnNTqe9hVf1aGNu1nr3/FTkLhPaJvgIn9De8=",
      "url": "_framework/System.Private.Uri.1v746y330a.wasm"
    },
    {
      "hash": "sha256-0WfH1IX9V5wVdJY7kz7OwBA7vq2CfgOUut0HNGyv/FY=",
      "url": "_framework/System.Runtime.5791redbph.wasm"
    },
    {
      "hash": "sha256-hvMt1IDwhfTaPJfe1fJ80HJ5eAum8hxykr0I3aDRcoE=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.un6jcmgrxl.wasm"
    },
    {
      "hash": "sha256-qWRckNgJUXP/8BMc9tmHvES2SMAuHimXyFmWjbXrfM8=",
      "url": "_framework/System.Text.Encodings.Web.z5osepan0o.wasm"
    },
    {
      "hash": "sha256-6AsIhvRYwpAq7dHUqhvKz5Wpw6UCGBkbUXXCTWYmXSk=",
      "url": "_framework/System.Text.Json.80a5qky8zc.wasm"
    },
    {
      "hash": "sha256-VdTVx7BqfLgxpexvMTkSI3N233xrnZp5GxwrZM9G28k=",
      "url": "_framework/System.Text.RegularExpressions.pjhal65ko1.wasm"
    },
    {
      "hash": "sha256-NKKMoiKIqcm6rQGovF18gOyoOGsZ09TwOfpHTnfJqKg=",
      "url": "_framework/WebApp.g3l81cjr1t.wasm"
    },
    {
      "hash": "sha256-hLMn5zraaTuAhldKMdJQioxyrqaSsj4ChDR1zFxKK1U=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-lh8bY3DINgTiqGL/cwOeVaJGdfE2ex1o8MzwCbmlZZE=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-tgrZh46Y3JaZ+PyFFOnGPVYBjDDetP1k9QAKJlurdVI=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-HlUDSN0oXsH1WmjLNtyyvh9W0WQWWPGv3SJsHPJAwTE=",
      "url": "_framework/dotnet.native.etgrtk5jba.wasm"
    },
    {
      "hash": "sha256-CU8oL4L0VAwGe3hCyxZDy7keJq9dcsWED0JKqrvlUb4=",
      "url": "_framework/dotnet.native.l1ds2rhypd.js"
    },
    {
      "hash": "sha256-5oRcSUQSLbUYyq9jPgwB6domrDHYrvLX+53QxY+0y48=",
      "url": "_framework/dotnet.runtime.2hocyfcbj2.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-/nhlB6Jvzx+6fgYSXdUKnQqDiFtIYYuDgRNOSnc6LnM=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-R7QqkKcIMkxizlTyFLJqHBV9TjPDu3CqGHNMOBrZabg=",
      "url": "css/app.scss"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-5Q133T2P8pYaBntdckBASY7TsVVmT5pXG8Gj62W53+A=",
      "url": "index.html"
    },
    {
      "hash": "sha256-s4nQ0gm4La8wA8++Y4nW7LUZ/mm/SebLqwnbf96ZQ6w=",
      "url": "manifest.webmanifest"
    }
  ]
};
